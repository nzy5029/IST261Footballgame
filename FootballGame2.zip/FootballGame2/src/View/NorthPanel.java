package View;

import java.awt.Color;
import java.util.Hashtable;
import javax.swing.*;
import javax.swing.border.TitledBorder;

public class NorthPanel extends JPanel
{
    private JSlider speed = new JSlider (JSlider.HORIZONTAL, 5,40,20);
    private final JLabel score;

    public NorthPanel()
    {
        super();
        
        setBackground(Color.ORANGE); 
        add(speed);
        TitledBorder title;
        title = BorderFactory.createTitledBorder("speed");
        title.setTitlePosition(TitledBorder.BELOW_BOTTOM);
        title.setTitleJustification(TitledBorder.TOP);
        speed.setPaintLabels(true);
        Hashtable table = new Hashtable();
        table.put(40, new JLabel("fast"));
        table.put(20, new JLabel("medium"));
        table.put(5, new JLabel("slow"));
        speed.setLabelTable(table);
        speed.setFocusable(false);
        score = new JLabel("Win: 0, Loss: 0");
        add(score);
}
    
    public int getSpeed(){
       return this.speed.getValue();
    } 
    public void setSpeed(JSlider spd)
    {
        this.speed = spd;
    }
     public JLabel getScore(){
      return this.score;
      
    }

}