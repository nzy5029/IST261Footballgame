package Controller;

import Model.Model;
import View.View;

public class Controller {

    private Model model;
    private View view;
   
    public Controller(Model imodel, View iview) {
        model = imodel;
        view = iview;
        view.initialSetup();
        view.getInitialframe().getInitialPanel().getWp().getHp().DisplayButtons(model.getFPData().getColumnNames());
        view.getInitialframe().getInitialPanel().getWp().getPp().DisplayLabels(model.getFPData().getLines(model.start(), model.end()));//0, 25));
        
    }
    
    public Model getModel() {
        return model;
    }

    public void setModel(Model model) {
        this.model = model;
    }

    public View getView() {
        return view;
    }

    public void setView(View view) {
        this.view = view;
    }

}