package Model;

public class Model
{

    private FootballPlayerData FPData;
    public int begin = 0;

    public Model()
    {
        FPData = new FootballPlayerData();
    }

    /**
     * @return the FPData
     */
    public FootballPlayerData getFPData()
    {
        return FPData;
    }

    /**
     * @param FPData the FPData to set
     */
    public void setFPData(FootballPlayerData FPData)
    {
        this.FPData = FPData;
    }
    
    public int start()
    {
        int start[] = new int[0];
        return start.length;
    }
    
    public int end()
    {
        int end[] = new int[6];
        return end.length;
    }

}