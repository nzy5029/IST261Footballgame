/*
Assignment: Project Deliverable 1 Football Game
Name: Kaitlyn, Niloofar, Wei-Lun
ID: kzd5345
Project Includes (what we promised for the first deliverable):
-Created the MVC model format
-Created several panels and elements that the user will see
-Player Panel that displays 6 players information (number, name, positiion, height, weight)
-North/Top Panel displays speed bar and scoreboard
-Started working on Center Panel (Football Field) and added players (will have functionality in later deliverable)
*/

import Model.Model;
import Controller.Controller;
import View.View;

public class FP_Starter
{
    public static void main(String[] args)
    {
        Model model = new Model();
        View view = new View();
        Controller controller = new Controller(model, view);
    }
}